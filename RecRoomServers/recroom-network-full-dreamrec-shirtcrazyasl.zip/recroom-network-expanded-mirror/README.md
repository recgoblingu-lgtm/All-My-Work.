# DreamRec expanded public mirror

This package is an expanded, source-linked static capture of publicly reachable pages from `https://recroom.network/`. It preserves the captured HTML, CSS, JavaScript, fonts, and public assets as closely as possible. Visible DreamRec references were changed to DreamRec, and the DreamRec photo/logo reference was removed as requested.

## Current snapshot

The bundled `.crawl-state.json` records the reusable crawler state for the latest bounded run. The snapshot reached dozens of public HTML routes and more than one hundred public assets before being packaged. It includes the earlier top-level pages plus newly discovered public routes and assets. Because the site is dynamic, the exact account and page count can change between refreshes.

## Refresh the mirror

From this directory, run:

```bash
node tools/crawl.mjs --seed https://recroom.network/ --out ./refresh-capture --max-pages 600 --max-assets 2500 --delay-ms 500
```

The crawler is resumable: rerun it against the same `--out` directory to continue queued work. Use `--refresh` to start a new crawl state. It only follows HTTP(S) URLs on `recroom.network`, `cdn.recroom.network`, and `img.recroom.network`; skips login, logout, OAuth, account settings, session/token, and API paths; writes a `.crawl-state.json`; and emits a report when it reaches a configured limit or exhausts the queue.

The crawler does not log in, submit forms, bypass access controls, collect private data, or use AI training. Keep the delay conservative and review the site’s current policies before increasing limits.

## Cloudflare Pages

Upload the contents of this directory to GitHub and connect the repository to Cloudflare Pages. Use the repository root as the output directory and no build command, or use `true` if a command is required. The `_redirects` file provides static fallbacks for the captured top-level routes.

## Coverage limits

This is not a guarantee of every account or every historical page. Public profiles and content that are only returned after client-side API calls, infinite scroll, search, authentication, or interaction may not be discoverable by a static HTML crawler. Login, comments, live feeds, search, checkout, API-backed updates, and other server-side behavior will not operate as an offline mirror. Continue refreshing the reusable crawler in small, reviewable runs and retain creator attribution, source links, licensing records, and takedown procedures.

Original source: https://recroom.network/
Capture date: 2026-08-20


## Public account capture

This package includes 458 public account/profile HTML captures discovered through the site’s public account-search service. Each profile is stored at its route-correct location under `user/<username>/index.html`, with aggregate records in `accounts.json` and capture status in `account-report.json` and `profile-report.json`.

To continue discovering public accounts, resume the enumerator from its saved state:

```bash
node tools/accounts.mjs --out ./account-capture --max-queries 1140 --delay-ms 350
node tools/capture-accounts.mjs --input ./account-capture/accounts.json --out ./profile-pages --delay-ms 400
```

The account set is the public searchable subset returned by the endpoint at capture time. It is not a guarantee of every account on the service. Private, authenticated, deleted, region-restricted, API-only, and dynamically loaded data is not included. The crawler does not bypass login or access controls.
