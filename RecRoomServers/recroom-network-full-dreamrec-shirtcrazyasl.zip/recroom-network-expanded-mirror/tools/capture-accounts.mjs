#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";

const args = new Map();
for (let i = 2; i < process.argv.length; i += 1) {
  const token = process.argv[i];
  if (token.startsWith("--")) args.set(token.slice(2), process.argv[i + 1]?.startsWith("--") ? "true" : (process.argv[++i] ?? "true"));
}
const input = path.resolve(args.get("input") || "./accounts.json");
const out = path.resolve(args.get("out") || "./profile-pages");
const delayMs = Number(args.get("delay-ms") || 400);
const limit = Number(args.get("limit") || 10000);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const source = JSON.parse(await fs.readFile(input, "utf8"));
const accounts = source.accounts || [];
const report = { startedAt: new Date().toISOString(), captured: [], failed: [] };
await fs.mkdir(out, { recursive: true });
for (const account of accounts.slice(0, limit)) {
  const username = String(account.username || "").trim();
  if (!username || /[\\/]/.test(username)) continue;
  const url = `https://recroom.network/user/${encodeURIComponent(username)}`;
  try {
    const response = await fetch(url, { headers: { "User-Agent": "DreamRec-PublicMirror/1.0 (+public account capture)" } });
    const body = await response.text();
    if (!response.ok || !body.includes("<html")) throw new Error(`HTTP ${response.status}`);
    const file = path.join(out, "user", username, "index.html");
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, body);
    report.captured.push({ username, accountId: account.accountId, source: url, file: path.relative(out, file), bytes: body.length });
  } catch (error) {
    report.failed.push({ username, accountId: account.accountId, source: url, error: String(error) });
  }
  await sleep(delayMs);
}
report.finishedAt = new Date().toISOString();
await fs.writeFile(path.join(out, "profile-report.json"), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ captured: report.captured.length, failed: report.failed.length }, null, 2));
