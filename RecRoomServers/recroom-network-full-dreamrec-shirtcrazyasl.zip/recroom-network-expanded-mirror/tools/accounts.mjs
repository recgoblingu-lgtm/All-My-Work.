#!/usr/bin/env node
/**
 * Enumerate publicly searchable Rec Room accounts without authentication.
 * The endpoint is queried by short username/display-name prefixes and results are deduplicated.
 */
import fs from "node:fs/promises";
import path from "node:path";

const args = new Map();
for (let i = 2; i < process.argv.length; i += 1) {
  const token = process.argv[i];
  if (token.startsWith("--")) args.set(token.slice(2), process.argv[i + 1]?.startsWith("--") ? "true" : (process.argv[++i] ?? "true"));
}
const out = path.resolve(args.get("out") || "./account-capture");
const api = args.get("api") || "https://apim.recroom.network/accounts/account/search";
const maxQueries = Number(args.get("max-queries") || 2000);
const maxAccounts = Number(args.get("max-accounts") || 100000);
const delayMs = Number(args.get("delay-ms") || 350);
const chars = args.get("chars") || "abcdefghijklmnopqrstuvwxyz0123456789_-.'";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const records = new Map();
const queries = [];
for (const a of chars) for (const b of chars) queries.push(a + b);
for (const a of chars) queries.push(a);

await fs.mkdir(out, { recursive: true });
const stateFile = path.join(out, ".account-state.json");
let state;
try { state = JSON.parse(await fs.readFile(stateFile, "utf8")); } catch { state = { nextQuery: 0, queried: [], errors: [] }; }
for (const item of state.accounts || []) records.set(String(item.accountId), item);
let count = 0;
for (; state.nextQuery < queries.length && count < maxQueries && records.size < maxAccounts; state.nextQuery += 1, count += 1) {
  const term = queries[state.nextQuery];
  if (state.queried.includes(term)) continue;
  try {
    const response = await fetch(`${api}?name=${encodeURIComponent(term)}`, { headers: { "User-Agent": "DreamRec-PublicAccountIndexer/1.0" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (Array.isArray(data)) for (const account of data) {
      if (account?.accountId && account?.username) records.set(String(account.accountId), account);
    }
    state.queried.push(term);
  } catch (error) {
    state.errors.push({ term, error: String(error), at: new Date().toISOString() });
  }
  state.accounts = [...records.values()];
  await fs.writeFile(stateFile, JSON.stringify(state, null, 2));
  await sleep(delayMs);
}
state.accounts = [...records.values()].sort((a, b) => String(a.username).localeCompare(String(b.username)));
await fs.writeFile(path.join(out, "accounts.json"), JSON.stringify({ generatedAt: new Date().toISOString(), accounts: state.accounts }, null, 2));
await fs.writeFile(path.join(out, "account-seeds.txt"), state.accounts.map((a) => `https://recroom.network/user/${encodeURIComponent(a.username)}`).join("\n") + "\n");
await fs.writeFile(path.join(out, "account-report.json"), JSON.stringify({ generatedAt: new Date().toISOString(), queriesRun: state.queried.length, accounts: state.accounts.length, errors: state.errors.length, nextQuery: state.nextQuery, remainingQueries: Math.max(0, queries.length - state.nextQuery), note: "Public searchable account records only; not a guarantee of every account. No login or private data." }, null, 2));
console.log(JSON.stringify({ queriesRun: state.queried.length, accounts: state.accounts.length, errors: state.errors.length, nextQuery: state.nextQuery, remainingQueries: Math.max(0, queries.length - state.nextQuery) }, null, 2));
