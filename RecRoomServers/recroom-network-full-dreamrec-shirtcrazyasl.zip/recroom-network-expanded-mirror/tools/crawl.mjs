#!/usr/bin/env node
/**
 * DreamRec public mirror crawler.
 * Public-only, resumable, rate-limited, and intentionally unable to log in or bypass access controls.
 */
import fs from "node:fs/promises";
import path from "node:path";
import { URL } from "node:url";

const args = new Map();
for (let i = 2; i < process.argv.length; i += 1) {
  const token = process.argv[i];
  if (token.startsWith("--")) args.set(token.slice(2), process.argv[i + 1]?.startsWith("--") ? "true" : (process.argv[++i] ?? "true"));
}
const seed = new URL(args.get("seed") || "https://recroom.network/");
const out = path.resolve(args.get("out") || "./mirror-capture");
const statePath = path.join(out, ".crawl-state.json");
const maxPages = Number(args.get("max-pages") || 5000);
const maxAssets = Number(args.get("max-assets") || 10000);
const delayMs = Number(args.get("delay-ms") || 1200);
const refresh = args.has("refresh");
const allowedHosts = new Set([seed.hostname, "cdn.recroom.network", "img.recroom.network"]);
const deniedPath = /(?:\/login|\/logout|\/oauth|\/auth|\/account\/settings|\/api\/|[?&](?:token|session|password)=)/i;
const htmlTypes = /text\/html/i;
const binaryAssetTypes = /(?:text\/css|javascript|font|image|video|audio|application\/json)/i;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch { return fallback; }
}
async function writeJson(file, value) { await fs.writeFile(file, JSON.stringify(value, null, 2)); }
async function ensureDir(file) { await fs.mkdir(path.dirname(file), { recursive: true }); }
function normalize(raw, base) {
  try {
    const url = new URL(raw, base);
    if (!/^https?:$/.test(url.protocol) || !allowedHosts.has(url.hostname) || deniedPath.test(url.pathname + url.search)) return null;
    url.hash = "";
    if (url.hostname === seed.hostname && (url.pathname === "/" || url.pathname.endsWith("/"))) url.search = "";
    return url;
  } catch { return null; }
}
function localPath(url, isHtml = false) {
  let pathname = decodeURIComponent(url.pathname);
  if (!pathname || pathname.endsWith("/")) pathname += "index.html";
  if (isHtml && !path.extname(pathname)) pathname += ".html";
  return path.join(out, url.hostname, pathname.replace(/^\/+/, ""));
}
function isLikelyAsset(url) { return /\.(?:css|js|mjs|json|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|mp4|webm|mp3|wav|pdf)(?:$|\?)/i.test(url.pathname); }
async function fetchWithRetry(url) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const response = await fetch(url, { redirect: "follow", headers: { "User-Agent": "DreamRec-PublicMirror/1.0 (+respectful archival crawler)" } });
      return response;
    } catch (error) {
      if (attempt === 1) throw error;
      await sleep(2000);
    }
  }
}

await fs.mkdir(out, { recursive: true });
const state = refresh ? { queue: [seed.href], seen: {}, pages: [], assets: [], errors: [] } : await readJson(statePath, { queue: [seed.href], seen: {}, pages: [], assets: [], errors: [] });
if (!state.queue.length && !refresh) state.queue.push(seed.href);
let requests = 0;
while (state.queue.length && state.pages.length < maxPages && state.assets.length < maxAssets) {
  const href = state.queue.shift();
  if (state.seen[href]) continue;
  const url = normalize(href, seed);
  if (!url) continue;
  state.seen[href] = { startedAt: new Date().toISOString() };
  try {
    if (requests > 0) await sleep(delayMs);
    requests += 1;
    const response = await fetchWithRetry(url.href);
    const type = response.headers.get("content-type") || "application/octet-stream";
    const isHtml = htmlTypes.test(type) || (!isLikelyAsset(url) && url.hostname === seed.hostname);
    const target = localPath(url, isHtml);
    const buffer = Buffer.from(await response.arrayBuffer());
    await ensureDir(target);
    await fs.writeFile(target, buffer);
    const record = { url: url.href, status: response.status, type, bytes: buffer.byteLength, file: path.relative(out, target), capturedAt: new Date().toISOString() };
    if (isHtml) {
      state.pages.push(record);
      const text = buffer.toString("utf8");
      const links = [...text.matchAll(/(?:href|src|poster)=["']([^"']+)["']/gi)].map((match) => match[1]);
      for (const raw of links) {
        const next = normalize(raw, url);
        if (!next || state.seen[next.href]) continue;
        if (isLikelyAsset(next) || next.hostname !== seed.hostname) state.queue.push(next.href);
        else state.queue.push(next.href);
      }
    } else state.assets.push(record);
    state.seen[href].doneAt = new Date().toISOString();
  } catch (error) {
    state.errors.push({ url: url.href, error: String(error), at: new Date().toISOString() });
  }
  await writeJson(statePath, state);
}
const report = { seed: seed.href, generatedAt: new Date().toISOString(), pages: state.pages.length, assets: state.assets.length, errors: state.errors.length, pending: state.queue.length, maxPages, maxAssets, delayMs, allowedHosts: [...allowedHosts], note: "Public-only crawl. No authentication, private content, access-control bypass, or AI-training use." };
await writeJson(path.join(out, "crawl-report.json"), report);
console.log(JSON.stringify(report, null, 2));
