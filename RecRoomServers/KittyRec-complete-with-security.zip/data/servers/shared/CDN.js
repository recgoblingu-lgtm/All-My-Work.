const chalk = require('chalk') // colored text
const express = require('express') //express.js - the web server
const morgan = require('morgan') //for webserver output
const app = express()
const security = require('../../shared/security')
security.applyExpressSecurity(app, { maxRequestsPerWindow: 60 })
const path = require("path")
app.use(morgan(`${chalk.magenta("[CDN]")} :method ":url" :status - :response-time ms`))
const { ports } = require("../../config.json")

let port;

function start(serveport = ports.IMG){
    try {
        port = serveport
        serve()
    } catch(e) {
        console.error(e)
    }
}

function serve() {
    app.get('/', (req, res) => {
        res.redirect("https://realmcoded.github.io/Rec.js/port-in-use.html")
    })
    /*
        Right now this only sends the users profile picture, as that is all the CDN appears to be used for in the context of 2017.
        The posters are still a big issue that i want to tackle, i just don't know how because it doesn't make any requests to the CDN for poster data.
    */
    app.get('/*', (req, res) => {
        if (req.path.length > 512 || req.path.includes('\\') || req.path.includes('..')) {
            security.writeAudit('cdn_path_rejected', { path: req.path });
            return res.status(400).json({ error: 'invalid_path' });
        }
        res.type('png');
        res.setHeader('Content-Disposition', 'inline');
        res.sendFile(path.resolve(`${__dirname}/../../user-info/ProfileImage.png`), { dotfiles: 'deny', acceptRanges: false, cacheControl: false }, (error) => {
            if (error && !res.headersSent) res.status(error.statusCode || 404).json({ error: 'asset_unavailable' });
        });
    })
    
    app.use(security.jsonErrorHandler);
    app.listen(port, () => {
        console.clear();

       console.log(`${chalk.yellowBright("KittyRec is ready! Please start RecRoom now.")}`)

    })
}

module.exports = { start }