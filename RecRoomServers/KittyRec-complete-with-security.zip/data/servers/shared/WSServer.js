"use strict";
const { WebSocketServer } = require("ws");
const chalk = require("chalk");
const crypto = require("crypto");
const security = require("../../shared/security");
const settings = require("../../config.json");
const ports = settings.ports || { WS: 20161 };
const privateRooms = Boolean(settings.privateRooms);
const userid = require("../../user-info/user.json").userid;
let started = false;
let server;
let connections = 0;
const allowedOrigins = new Set((process.env.KITTYREC_WS_ORIGINS || "").split(",").map((value) => value.trim()).filter(Boolean));
function start(servePort = ports.WS || 20161) {
    if (started) return;
    started = true;
    server = new WebSocketServer({
        port: Number.isInteger(Number(servePort)) ? Number(servePort) : 20161,
        maxPayload: security.config().maxWebSocketPayloadBytes,
        clientTracking: true,
        perMessageDeflate: false,
        verifyClient: ({ origin, req }) => {
            if (allowedOrigins.size && origin && !allowedOrigins.has(origin)) { security.writeAudit("ws_origin_rejected", { origin }); return false; }
            if (connections >= security.config().maxWebSocketConnections) { security.writeAudit("ws_connection_rejected", { host: req.headers.host }); return false; }
            return true;
        },
    });
    server.on("connection", onConnection);
    server.on("error", (error) => security.writeAudit("ws_server_error", { message: error.message }));
    server.on("listening", () => console.log(`${chalk.blueBright("[WS]")} WS started on port ${servePort}`));
}
function onConnection(ws, req) {
    connections += 1;
    const key = `${req.socket.remoteAddress || "unknown"}:${crypto.randomUUID()}`;
    ws.isAlive = true;
    ws.on("pong", () => { ws.isAlive = true; });
    ws.on("message", (raw, isBinary) => {
        if (isBinary || raw.length > security.config().maxWebSocketPayloadBytes) return close(ws, 1009, "message too large");
        if (security.isRateLimited(key, security.config().maxWebSocketMessagesPerWindow, security.config().websocketMessageWindowMs)) return close(ws, 1008, "rate limited");
        const payload = security.parseJsonSafely(raw.toString(), null);
        if (!payload || !security.validateObject(payload, 4) || typeof payload !== "object" || Array.isArray(payload)) return close(ws, 1007, "invalid message");
        processRequest(payload).then((response) => { if (ws.readyState === ws.OPEN) ws.send(response); }).catch(() => close(ws, 1011, "request failed"));
    });
    ws.on("error", (error) => security.writeAudit("ws_client_error", { message: error.message }));
    ws.on("close", () => { connections = Math.max(0, connections - 1); });
    const timer = setInterval(() => { if (!ws.isAlive) return ws.terminate(); ws.isAlive = false; ws.ping(); }, 30_000);
    timer.unref?.();
    ws.once("close", () => clearInterval(timer));
}
function close(ws, code, reason) { security.writeAudit("ws_message_rejected", { code, reason }); if (ws.readyState === ws.OPEN) ws.close(code, reason); }
async function processRequest(data) {
    if (data.api === "playerSubscriptions/v1/update") return JSON.stringify({ Id: 12, Msg: { PlayerId: userid, IsOnline: true, InScreenMode: false, GameSession: null } });
    if (data.api === "heartbeat2") return JSON.stringify({ Id: 4, Msg: { PlayerId: userid, IsOnline: true, InScreenMode: false, GameSession: null } });
    if (data.api !== undefined) return "";
    return JSON.stringify({ SessionId: privateRooms ? crypto.randomInt(0, 100) : 20171 });
}
module.exports = { start, processRequest };
