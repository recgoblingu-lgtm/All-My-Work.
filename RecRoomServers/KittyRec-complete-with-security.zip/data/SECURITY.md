# KittyRec Security Baseline

This fork adds a defense-in-depth security baseline for the legacy HTTP, CDN, and WebSocket services. The controls are intentionally conservative so the old client protocols continue to work while malformed, abusive, or unexpectedly large requests are rejected early.

## Added controls

1. Environment-first upstream secret loading.
2. Optional fallback secret-file loading for legacy installations.
3. Secret-file permission auditing.
4. Secret redaction in audit records.
5. Authorization, token, and password redaction.
6. Correlation IDs for every HTTP request.
7. Validation of caller-supplied correlation IDs.
8. Removal of the Express powered-by banner.
9. Explicitly disabled proxy trust by default.
10. `X-Content-Type-Options: nosniff`.
11. `X-Frame-Options: DENY`.
12. `Referrer-Policy: no-referrer`.
13. Restrictive `Permissions-Policy`.
14. Default-deny `Content-Security-Policy`.
15. Same-origin `Cross-Origin-Resource-Policy`.
16. No-store response caching.
17. Explicit HTTP method allowlist.
18. Oversized `Content-Length` rejection.
19. Invalid negative `Content-Length` rejection.
20. Maximum request body size.
21. Strict JSON parsing.
22. Non-extended URL-encoded parsing.
23. URL-encoded parameter-count cap.
24. Request timeout enforcement.
25. Concurrent-request cap.
26. Per-client HTTP rate limiting.
27. Retry-After responses for rate-limited callers.
28. Stale rate-limit bucket cleanup.
29. Structured JSON audit logging.
30. Control-character removal from audit values.
31. Safe serialization of audit values.
32. Generic client-facing error responses.
33. Internal error audit logging.
34. Slow-request audit events.
35. Request-timeout audit events.
36. Rejection audit events for abusive traffic.
37. Bounded recursive object validation.
38. Array-size validation.
39. Object-key length validation.
40. Control-character sanitization helper.
41. Strict identifier validation helper.
42. Finite numeric-range validation helper.
43. HTTP(S) URL validation helper.
44. Hashing helper for non-reversible log correlation.
45. Constant-time comparison helper.
46. Safe JSON parsing helper.
47. Cryptographically secure random integer generation.
48. WebSocket maximum payload enforcement.
49. WebSocket origin allowlisting when configured.
50. WebSocket connection, message-rate, heartbeat, binary-message, and protocol-error controls.

## Operational notes

Set `KITTYREC_UPSTREAM_TOKEN` in the process environment for production deployments. The legacy `user-info/token.txt` fallback remains for compatibility, but it should be removed from source control and restricted to mode `0600`. The token already present in repository history should be treated as compromised and rotated by the operator.

The hardening layer is not a substitute for TLS termination, firewall rules, OS account isolation, dependency updates, backups, or a full protocol-level authorization design. Operators should place the services behind a reverse proxy with HTTPS and expose only the ports required by the selected client build.
