"use strict";

const assert = require("assert");
const security = require("../shared/security");

assert.strictEqual(security.safeId("player_123"), "player_123");
assert.strictEqual(security.safeId("../secret"), null);
assert.strictEqual(security.safeNumber("12", 0, 20), 12);
assert.strictEqual(security.safeNumber("NaN"), null);
assert.ok(security.safeUrl("https://example.com", ["example.com"]));
assert.strictEqual(security.safeUrl("file:///etc/passwd"), null);
assert.strictEqual(security.sanitizeText("hello\u0000world"), "helloworld");
assert.strictEqual(security.validateObject({ a: [1, 2], b: { c: true } }), true);
assert.strictEqual(security.validateObject({ a: { b: { c: { d: { e: { f: 1 } } } } } }, 4), false);
assert.strictEqual(security.parseJsonSafely('{"ok":true}').ok, true);
assert.strictEqual(security.parseJsonSafely("not-json", "fallback"), "fallback");
assert.strictEqual(security.constantTimeEqual("same", "same"), true);
assert.strictEqual(security.constantTimeEqual("same", "different"), false);
assert.ok(Number.isInteger(security.secureRandomInt(1, 1)));
assert.strictEqual(security.isAllowedMethod("GET"), true);
assert.strictEqual(security.isAllowedMethod("TRACE"), false);
console.log("security helper tests passed");
