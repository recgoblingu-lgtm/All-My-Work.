"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const DEFAULTS = Object.freeze({
    maxBodyBytes: 1024 * 1024,
    maxHeaderBytes: 16 * 1024,
    requestTimeoutMs: 15_000,
    maxRequestsPerWindow: 120,
    rateWindowMs: 60_000,
    maxConcurrentRequests: 100,
    maxWebSocketPayloadBytes: 64 * 1024,
    maxWebSocketConnections: 100,
    maxWebSocketMessagesPerWindow: 60,
    websocketMessageWindowMs: 10_000,
    allowedMethods: ["GET", "POST", "PATCH", "OPTIONS"],
});

const buckets = new Map();
let activeRequests = 0;

function config() {
    return {
        ...DEFAULTS,
        maxBodyBytes: positiveInt(process.env.KITTYREC_MAX_BODY_BYTES, DEFAULTS.maxBodyBytes),
        requestTimeoutMs: positiveInt(process.env.KITTYREC_REQUEST_TIMEOUT_MS, DEFAULTS.requestTimeoutMs),
        maxRequestsPerWindow: positiveInt(process.env.KITTYREC_RATE_LIMIT, DEFAULTS.maxRequestsPerWindow),
        rateWindowMs: positiveInt(process.env.KITTYREC_RATE_WINDOW_MS, DEFAULTS.rateWindowMs),
        maxConcurrentRequests: positiveInt(process.env.KITTYREC_MAX_CONCURRENT, DEFAULTS.maxConcurrentRequests),
        maxWebSocketPayloadBytes: positiveInt(process.env.KITTYREC_WS_MAX_PAYLOAD, DEFAULTS.maxWebSocketPayloadBytes),
        maxWebSocketConnections: positiveInt(process.env.KITTYREC_WS_MAX_CONNECTIONS, DEFAULTS.maxWebSocketConnections),
    };
}

function positiveInt(value, fallback) {
    const parsed = Number.parseInt(value, 10);
    return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function clientKey(req) {
    const forwarded = req.headers["x-forwarded-for"];
    const address = typeof forwarded === "string" ? forwarded.split(",")[0].trim() : req.socket?.remoteAddress;
    return String(address || "unknown").slice(0, 128);
}

function correlationId(req) {
    const supplied = req.get("x-request-id");
    return /^[A-Za-z0-9._-]{1,80}$/.test(supplied || "") ? supplied : crypto.randomUUID();
}

function redact(value) {
    return String(value || "")
        .replace(/(authorization\s*[:=]\s*)([^,\s]+)/gi, "$1[REDACTED]")
        .replace(/(token\s*[:=]\s*)([^,\s]+)/gi, "$1[REDACTED]")
        .replace(/(password\s*[:=]\s*)([^,\s]+)/gi, "$1[REDACTED]")
        .replace(/[\u0000-\u001f\u007f]/g, "");
}

function safeJson(value) {
    try {
        return JSON.stringify(value);
    } catch (_) {
        return "[unserializable]";
    }
}

function writeAudit(event, details = {}) {
    const record = {
        timestamp: new Date().toISOString(),
        event: redact(event),
        ...Object.fromEntries(Object.entries(details).map(([key, value]) => [key, redact(typeof value === "string" ? value : safeJson(value))])),
    };
    const line = `${JSON.stringify(record)}\n`;
    const logDir = path.resolve(__dirname, "../logs");
    try {
        fs.mkdirSync(logDir, { recursive: true, mode: 0o750 });
        fs.appendFileSync(path.join(logDir, "security.log"), line, { mode: 0o640 });
    } catch (error) {
        console.error("[SECURITY] audit write failed:", error.message);
    }
}

function setSecurityHeaders(res) {
    res.removeHeader("X-Powered-By");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    res.setHeader("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'; base-uri 'none'");
    res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
    res.setHeader("Cache-Control", "no-store");
}

function isAllowedMethod(method, allowed = config().allowedMethods) {
    return allowed.includes(String(method || "").toUpperCase());
}

function isRateLimited(key, limit = config().maxRequestsPerWindow, windowMs = config().rateWindowMs) {
    const now = Date.now();
    const previous = buckets.get(key);
    if (!previous || now - previous.startedAt >= windowMs) {
        buckets.set(key, { startedAt: now, count: 1 });
        return false;
    }
    previous.count += 1;
    return previous.count > limit;
}

function cleanupBuckets() {
    const cutoff = Date.now() - Math.max(config().rateWindowMs, config().websocketMessageWindowMs) * 2;
    for (const [key, bucket] of buckets) {
        if (bucket.startedAt < cutoff) buckets.delete(key);
    }
}

function applyExpressSecurity(app, options = {}) {
    const settings = { ...config(), ...options };
    app.disable("x-powered-by");
    app.set("trust proxy", false);
    app.use((req, res, next) => {
        const id = correlationId(req);
        const started = process.hrtime.bigint();
        res.setHeader("X-Request-ID", id);
        setSecurityHeaders(res);
        if (!isAllowedMethod(req.method, settings.allowedMethods)) {
            writeAudit("method_rejected", { id, method: req.method, path: req.path });
            return res.status(405).json({ error: "method_not_allowed", requestId: id });
        }
        if (Number(req.headers["content-length"] || 0) > settings.maxBodyBytes) {
            writeAudit("body_rejected", { id, path: req.path });
            return res.status(413).json({ error: "payload_too_large", requestId: id });
        }
        if (Number(req.headers["content-length"] || 0) < 0 || Number(req.headers["content-length"] || 0) > settings.maxHeaderBytes * 64) {
            return res.status(400).json({ error: "invalid_content_length", requestId: id });
        }
        if (isRateLimited(clientKey(req), settings.maxRequestsPerWindow, settings.rateWindowMs)) {
            writeAudit("rate_limited", { id, path: req.path });
            res.setHeader("Retry-After", Math.ceil(settings.rateWindowMs / 1000));
            return res.status(429).json({ error: "rate_limited", requestId: id });
        }
        if (activeRequests >= settings.maxConcurrentRequests) {
            writeAudit("concurrency_rejected", { id, path: req.path });
            return res.status(503).json({ error: "server_busy", requestId: id });
        }
        activeRequests += 1;
        let finished = false;
        const release = () => {
            if (finished) return;
            finished = true;
            activeRequests = Math.max(0, activeRequests - 1);
            const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
            if (elapsedMs > settings.requestTimeoutMs) writeAudit("slow_request", { id, path: req.path, elapsedMs: Math.round(elapsedMs) });
        };
        res.once("finish", release);
        res.once("close", release);
        req.setTimeout(settings.requestTimeoutMs, () => {
            writeAudit("request_timeout", { id, path: req.path });
            if (!res.headersSent) res.status(408).json({ error: "request_timeout", requestId: id });
            req.destroy();
        });
        next();
    });
    return app;
}

function jsonErrorHandler(error, req, res, _next) {
    const id = res.getHeader("X-Request-ID") || correlationId(req);
    writeAudit("request_error", { id, path: req.path, message: error?.message });
    if (res.headersSent) return;
    const status = error?.type === "entity.too.large" ? 413 : 400;
    res.status(status).json({ error: status === 413 ? "payload_too_large" : "invalid_request", requestId: id });
}

function validateObject(value, maxDepth = 5, depth = 0) {
    if (depth > maxDepth) return false;
    if (value === null || typeof value !== "object") return true;
    if (Array.isArray(value) && value.length > 1000) return false;
    return Object.entries(value).every(([key, child]) => key.length <= 128 && validateObject(child, maxDepth, depth + 1));
}

function sanitizeText(value, maxLength = 256) {
    return typeof value === "string" ? value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").slice(0, maxLength) : value;
}

function safeId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(value) ? value : null;
}

function safeNumber(value, min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER) {
    const number = typeof value === "number" ? value : Number(value);
    return Number.isFinite(number) && number >= min && number <= max ? number : null;
}

function safeUrl(value, allowedHosts = []) {
    try {
        const url = new URL(value);
        return ["https:", "http:"].includes(url.protocol) && (allowedHosts.length === 0 || allowedHosts.includes(url.hostname)) ? url : null;
    } catch (_) {
        return null;
    }
}

function loadSecret({ env, file, required = false } = {}) {
    const fromEnv = env ? process.env[env] : undefined;
    if (fromEnv) return String(fromEnv).trim();
    if (file) {
        try {
            const stat = fs.statSync(file);
            if ((stat.mode & 0o077) !== 0) writeAudit("insecure_secret_permissions", { file });
            const value = fs.readFileSync(file, "utf8").trim();
            if (value) return value;
        } catch (error) {
            if (required) throw new Error("required secret is unavailable");
        }
    }
    if (required) throw new Error("required secret is unavailable");
    return "";
}

function hashForLog(value) {
    return crypto.createHash("sha256").update(String(value || "")).digest("hex").slice(0, 16);
}

function constantTimeEqual(a, b) {
    const left = Buffer.from(String(a || ""));
    const right = Buffer.from(String(b || ""));
    return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function parseJsonSafely(value, fallback = null) {
    try {
        return JSON.parse(value);
    } catch (_) {
        return fallback;
    }
}

function secureRandomInt(min, max) {
    if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max < min) throw new TypeError("invalid random range");
    return crypto.randomInt(min, max + 1);
}

const interval = setInterval(cleanupBuckets, Math.max(config().rateWindowMs, 30_000));
interval.unref?.();

module.exports = {
    DEFAULTS,
    config,
    applyExpressSecurity,
    jsonErrorHandler,
    setSecurityHeaders,
    isAllowedMethod,
    isRateLimited,
    validateObject,
    sanitizeText,
    safeId,
    safeNumber,
    safeUrl,
    hashForLog,
    loadSecret,
    constantTimeEqual,
    parseJsonSafely,
    secureRandomInt,
    writeAudit,
};
