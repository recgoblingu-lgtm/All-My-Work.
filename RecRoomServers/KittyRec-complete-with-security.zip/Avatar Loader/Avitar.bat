python filename.py
pause