using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Enable broad CORS permissions so the Unity Engine handles localhost headers cleanly
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});

// Register HttpClient to handle outbound Webhook file transmissions safely
builder.Services.AddHttpClient();

var app = builder.Build();
app.UseCors();
app.UseWebSockets(); 

// -------------------------------------------------------------------------
// CONFIGURATION CONFIG: Insert your Discord or custom Webhook URL link here
// -------------------------------------------------------------------------
const string TargetWebhookUrl = "YOUR_WEBHOOK_URL_HERE";

// Establish a local file-based database for account storage if it doesn't exist
const string DbFile = "dreamrec_database.json";
if (!File.Exists(DbFile))
{
    var defaultDb = new {
        PlayerId = 999111,
        Username = "DreamPlayer",
        RegistrationStatus = 1,
        Level = 50,
        XP = 125000
    };
    File.WriteAllText(DbFile, JsonSerializer.Serialize(defaultDb));
}

// =========================================================================
// 1. CONFIG ENDPOINT: Instructs the 2021 client to treat our pipeline as secure
// =========================================================================
app.MapGet("/api/config/v2", async (HttpContext context) =>
{
    var fullConfig = new
    {
        CdnUrl = "http://localhost:2056",
        UseAuthentication = true,
        MatchmakingAddress = "localhost",
        WebSocketSettings = new { HubUrl = "ws://localhost:2056/hub" },
        ValidVersions = new[] { "all", "2021", "202106", "202107", "202108", "production" },
        Features = new {
            VoiceChat = true,
            CustomRooms = true,
            MakerPen = true,
            NewDorm = true
        }
    };
    context.Response.ContentType = "application/json";
    await context.Response.WriteAsJsonAsync(fullConfig);
});

// =========================================================================
// 2. IMAGE SERVER: Intercept Camera Captures and Relay to Webhook
// =========================================================================
app.MapPost("/api/images/v4/upload", async (HttpContext context, IHttpClientFactory httpClientFactory) =>
{
    // 1. Read the raw byte array stream sent straight from the in-game camera
    using var ms = new MemoryStream();
    await context.Request.Body.CopyToAsync(ms);
    byte[] imageBytes = ms.ToArray();

    Console.WriteLine($"[DreamRec Image Server]: Intercepted photo capture ({imageBytes.Length} bytes).");

    // 2. Route the file forward if a valid target webhook has been established
    if (!string.IsNullOrEmpty(TargetWebhookUrl) && TargetWebhookUrl.StartsWith("http"))
    {
        try
        {
            var client = httpClientFactory.CreateClient();
            using var form = new MultipartFormDataContent();
            using var fileContent = new ByteArrayContent(imageBytes);
            
            // Format content type headers to match standard image forms
            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("image/png");
            
            // Format form structure for common endpoints like Discord or Slack hooks
            form.Add(fileContent, "file", $"DreamRec_Capture_{DateTime.UtcNow.Ticks}.png");
            form.Add(new StringContent("📸 **A picture was taken inside DreamRec!**"), "content");

            var response = await client.PostAsync(TargetWebhookUrl, form);
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("[DreamRec Image Server]: Photo relayed to Webhook successfully.");
            }
            else
            {
                Console.WriteLine($"[DreamRec Image Server Warning]: Webhook rejected payload with status: {response.StatusCode}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[DreamRec Image Server Error]: Failed to route capture stream: {ex.Message}");
        }
    }
    else
    {
        Console.WriteLine("[DreamRec Image Server]: Webhook ignored. Configure TargetWebhookUrl to forward captures.");
    }

    // Return a valid mock Image ID registration payload back to the game engine to satisfy the UI loop
    var mockImageResult = new
    {
        ImageId = 1234567,
        PlayerId = 999111,
        Url = "http://localhost:2056/cached_image.png"
    };
    
    await context.Response.WriteAsJsonAsync(mockImageResult);
});

// =========================================================================
// 3. AUTHENTICATION MATRIX (Actual Login Verification)
// =========================================================================
app.MapPost("/api/players/v1/getOrCreate", async (HttpContext context) =>
{
    var dbText = await File.ReadAllTextAsync(DbFile);
    using var doc = JsonDocument.Parse(dbText);
    var root = doc.RootElement;

    var response = new {
        Result = 1, 
        PlayerId = root.GetProperty("PlayerId").GetInt32(),
        Token = "DreamRec_Session_Handshake_Secure_Token"
    };
    await context.Response.WriteAsJsonAsync(response);
});

app.MapPost("/api/players/v1/login", async (HttpContext context) =>
{
    var dbText = await File.ReadAllTextAsync(DbFile);
    using var doc = JsonDocument.Parse(dbText);
    var root = doc.RootElement;

    var loginResult = new {
        Result = 1,
        Token = "DreamRec_Bearer_Access_Token_" + Guid.NewGuid().ToString().Substring(0, 8),
        PlayerId = root.GetProperty("PlayerId").GetInt32(),
        DisplayName = root.GetProperty("Username").GetString(),
        RegistrationStatus = root.GetProperty("RegistrationStatus").GetInt32()
    };
    await context.Response.WriteAsJsonAsync(loginResult);
});

app.MapPost("/api/players/v1/platformLogin", async (HttpContext context) =>
{
    var dbText = await File.ReadAllTextAsync(DbFile);
    using var doc = JsonDocument.Parse(dbText);
    var root = doc.RootElement;

    var platformResult = new {
        Result = 1,
        Token = "DreamRec_Platform_Validated_Token",
        PlayerId = root.GetProperty("PlayerId").GetInt32()
    };
    await context.Response.WriteAsJsonAsync(platformResult);
});

app.MapGet("/api/players/v1/progression", async (HttpContext context) =>
{
    var dbText = await File.ReadAllTextAsync(DbFile);
    using var doc = JsonDocument.Parse(dbText);
    var root = doc.RootElement;

    var progression = new {
        Level = root.GetProperty("Level").GetInt32(),
        Experience = root.GetProperty("XP").GetInt32()
    };
    await context.Response.WriteAsJsonAsync(progression);
});

// =========================================================================
// 4. WARDROBE ENDPOINT: Full structural item catalog mapping for 2021
// =========================================================================
app.MapGet("/api/avatar/v2", async (HttpContext context) =>
{
    var completeWardrobe = new
    {
        UnlockedItems = new[]
        {
            new { ItemId = "hair_messy_01", Type = 1, Name = "Messy Hair" },
            new { ItemId = "hair_curly_01", Type = 1, Name = "Curly Afro" },
            new { ItemId = "hair_dreads_01", Type = 1, Name = "Short Dreads" },
            new { ItemId = "shirt_hoodie_black", Type = 2, Name = "DreamRec Logo Hoodie" },
            new { ItemId = "shirt_tshirt_white", Type = 2, Name = "Basic White Tee" },
            new { ItemId = "shirt_jacket_varsity", Type = 2, Name = "Varsity Jacket" },
            new { ItemId = "pants_cargo_01", Type = 3, Name = "Black Cargo Pants" },
            new { ItemId = "pants_jeans_blue", Type = 3, Name = "Classic Blue Jeans" },
            new { ItemId = "skin_pale_01", Type = 4, Name = "Fair Skin" },
            new { ItemId = "skin_tan_01", Type = 4, Name = "Olive Skin" },
            new { ItemId = "hat_beanie_slouchy", Type = 5, Name = "Slouchy Beanie" },
            new { ItemId = "gloves_fingerless", Type = 6, Name = "Fingerless Gloves" },
            new { ItemId = "glasses_nerd_black", Type = 7, Name = "Nerd Glasses" }
        },
        AvatarData = new
        {
            Hair = "hair_messy_01",
            Shirt = "shirt_hoodie_black",
            Pants = "pants_cargo_01",
            SkinColor = "skin_pale_01",
            Hat = "hat_beanie_slouchy",
            Gloves = "gloves_fingerless",
            Glasses = "none",
            FaceFeatures = "{\"Eyes\":1,\"Mouth\":2,\"Eyebrows\":1}",
            SkinColorPaletteId = "skin_pale_01",
            HairColorPaletteId = "hair_color_brown"
        }
    };
    context.Response.ContentType = "application/json";
    await context.Response.WriteAsJsonAsync(completeWardrobe);
});

// =========================================================================
// 5. ROOMS ENDPOINT: Explicit scene directives to spawn directly into the Dorm
// =========================================================================
app.MapGet("/api/rooms/v1/home", async (HttpContext context) =>
{
    var homeDormDefinition = new
    {
        RoomId = 55577,
        Name = "MyDreamDormRoom",
        SceneName = "DormRoom", 
        MaxPlayers = 1,
        IsPublic = false,
        SupportsMakerPen = true,
        Data = "{}", 
        CreatorPlayerId = 999111,
        Tags = new[] { "sandbox", "home" }
    };
    await context.Response.WriteAsJsonAsync(homeDormDefinition);
});

app.MapGet("/api/settings/v1", async (HttpContext context) =>
{
    await context.Response.WriteAsJsonAsync(new { });
});

app.MapPost("/api/matchmaking/v1/rooms/createOrJoin", async (HttpContext context) =>
{
    var matchResponse = new {
        Result = 1,
        RoomId = 55577,
        RoomName = "MyDreamDormRoom"
    };
    await context.Response.WriteAsJsonAsync(matchResponse);
});

// =========================================================================
// 6. NOTIFICATION HUB ROUTE: Continuous ping loop to hold client focus
// =========================================================================
app.MapGet("/hub", async (HttpContext context) =>
{
    if (context.WebSockets.IsWebSocketRequest)
    {
        using var ws = await context.WebSockets.AcceptWebSocketAsync();
        var buffer = new byte[1024 * 4];
        
        while (ws.State == WebSocketState.Open)
        {
            var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (result.MessageType == WebSocketMessageType.Close)
            {
                await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed cleanly", CancellationToken.None);
            }
        }
    }
    else
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
    }
});

app.Run("http://localhost:2056");
