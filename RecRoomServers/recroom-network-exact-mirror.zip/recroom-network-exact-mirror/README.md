# recroom.network exact-mirror capture

This package is a faithful static capture of the public HTML, linked stylesheets, scripts, fonts, and public assets that were reachable during the capture window from `https://recroom.network/`. It preserves the original page markup and asset references rather than applying a redesign.

## Deploy with Cloudflare Pages

Upload this directory to a GitHub repository and connect it to Cloudflare Pages. Because the package is already static, use an empty build command and set the output directory to the repository root. If Cloudflare requires a build command, use `true`. The included `_redirects` file maps the captured top-level routes to their downloaded HTML files.

## Captured public routes

The capture includes the homepage, Shop, Creator Hub, Download, News, Events, Rooms, several Creator pages, and several featured room pages that were reachable from the public site during the crawl. The package also includes the Next.js assets and public CDN assets downloaded with those pages.

## Important limits

This is a static capture, not a running copy of Rec Room’s backend. Login, comments, search requests, live feeds, checkout, server-rendered updates, API calls, and other authenticated or dynamic behavior may not function offline. The capture also reflects the pages and assets available at the time of collection; it is not a guarantee that every historical or dynamically discovered route is present.

Review the licensing and attribution scope for every third-party asset before public redistribution. Keep creator attribution and source links intact, honor deletion and takedown requests, and do not use this capture to bypass access controls or to collect private/authenticated content.

## Source

Original source: https://recroom.network/

Capture date: 2026-08-20
