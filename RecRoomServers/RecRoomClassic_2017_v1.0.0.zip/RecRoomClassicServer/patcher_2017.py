import os
import re

# Endpoints used in 2017 builds
ENDPOINTS = [
    b"api.rec.net",
    b"auth.rec.net",
    b"match.rec.net",
    b"rooms.rec.net",
    b"images.rec.net",
    b"storage.rec.net",
    b"www.rec.net"
]

TARGET_URL = b"localhost:5000"

def patch_file(file_path):
    if not os.path.exists(file_path):
        return False

    print(f"[*] Patching: {file_path}")
    with open(file_path, 'rb') as f:
        data = f.read()

    original_size = len(data)
    patched_count = 0

    for endpoint in ENDPOINTS:
        if endpoint in data:
            # We must maintain the string length for binary safety in many cases,
            # but since localhost:5000 is usually shorter than the subdomains,
            # we can pad with null bytes or just replace if it's a metadata file.
            # For 2017 Mono DLLs, we can often just replace.
            
            # Simple replacement
            new_data = data.replace(endpoint, TARGET_URL)
            if len(new_data) != original_size:
                # If size changed, we might need padding depending on the file type.
                # For now, let's try direct replacement as most 2017 tools do.
                pass
            data = new_data
            patched_count += 1

    with open(file_path, 'wb') as f:
        f.write(data)

    print(f"[+] Patched {patched_count} endpoints in {os.path.basename(file_path)}")
    return True

def find_and_patch(base_dir):
    # Common locations for 2017 builds
    # 1. Mono: Rec Room_Data/Managed/Assembly-CSharp.dll
    # 2. IL2CPP: Rec Room_Data/Managed/Metadata/global-metadata.dat
    
    found = False
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            if file == "Assembly-CSharp.dll" or file == "global-metadata.dat":
                if patch_file(os.path.join(root, file)):
                    found = True
    
    if not found:
        print("[!] No patchable files found in the directory.")
    else:
        print("[+] 2017 Build Patched successfully for localhost:5000!")

if __name__ == "__main__":
    print("========================================")
    print("   REC ROOM 2017 CLASSIC PATCHER")
    print("========================================")
    path = input("Enter the path to your Rec Room 2017 folder: ").strip()
    if os.path.isdir(path):
        find_and_patch(path)
    else:
        print("[!] Invalid directory.")
    input("\nPress Enter to exit...")
