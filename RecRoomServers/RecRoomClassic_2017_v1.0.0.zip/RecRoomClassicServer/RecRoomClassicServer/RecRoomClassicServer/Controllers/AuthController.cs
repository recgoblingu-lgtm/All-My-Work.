using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecRoomClassicServer.Data;
using RecRoomClassicServer.Models;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace RecRoomClassicServer.Controllers
{
    [ApiController]
    [Route("api/v1/accounts")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;

        public AuthController(AppDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromForm] string username, [FromForm] string password)
        {
            // Simple Auto-Registration for 2017
            var account = await _db.Accounts.FirstOrDefaultAsync(a => a.Username == username);
            if (account == null)
            {
                account = new Account
                {
                    Username = username,
                    PasswordHash = password, // In production, use hashing!
                    DisplayName = username,
                    Email = $"{username}@localhost"
                };
                _db.Accounts.Add(account);
                await _db.SaveChangesAsync();
            }

            var token = GenerateJwtToken(account);

            return Ok(new
            {
                AccessToken = token,
                AccountId = account.AccountId,
                Username = account.Username,
                DisplayName = account.DisplayName,
                RegistrationStatus = account.RegistrationStatus
            });
        }

        private string GenerateJwtToken(Account account)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Secret"] ?? "default_secret_key_32_chars_long!!"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, account.AccountId.ToString()),
                new Claim(ClaimTypes.Name, account.Username)
            };

            var token = new JwtSecurityToken(
                issuer: "RecRoomClassic",
                audience: "RecRoomClient",
                claims: claims,
                expires: DateTime.Now.AddDays(30),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
