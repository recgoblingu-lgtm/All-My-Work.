using Microsoft.AspNetCore.Mvc;

namespace RecRoomClassicServer.Controllers
{
    [ApiController]
    [Route("api/config")]
    public class ConfigController : ControllerBase
    {
        [HttpGet("v2")]
        public IActionResult GetConfigV2()
        {
            return Ok(new
            {
                MessageOfTheDay = "Welcome to your Rec Room 2017 Private Server!",
                CdnBaseUri = "http://localhost:5000/",
                LevelProgressionMaps = GetLevelProgressionMaps(),
                MatchmakingParams = new { PreferEmptyRoomsFrequency = 0f, PreferFullRoomsFrequency = 1f },
                DailyObjectives = GetDailyObjectives(),
                ConfigTable = new[] 
                { 
                    new { Key = "Gift.DropChance", Value = "0.5" },
                    new { Key = "Gift.XP", Value = "0.5" }
                },
                PhotonConfig = new 
                { 
                    CloudRegion = "us", 
                    CrcCheckEnabled = false, 
                    EnableServerTracingAfterDisconnect = false 
                }
            });
        }

        private object[] GetLevelProgressionMaps()
        {
            var maps = new object[21];
            for (int i = 0; i <= 20; i++)
            {
                maps[i] = new { Level = i, RequiredXp = i * 100 + 100 };
            }
            return maps;
        }

        private object[][] GetDailyObjectives()
        {
            return new[]
            {
                new[] { new { type = 20, score = 1 }, new { type = 21, score = 1 } },
                new[] { new { type = 20, score = 1 }, new { type = 22, score = 1 } }
            };
        }
    }

    [ApiController]
    [Route("api/versioncheck")]
    public class VersionCheckController : ControllerBase
    {
        [HttpGet("v3")]
        public IActionResult CheckVersion()
        {
            return Ok(new { ValidVersion = true });
        }
    }
}
