using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using RecRoomClassicServer.Data;
using RecRoomClassicServer.Models;

namespace RecRoomClassicServer.Controllers
{
    [ApiController]
    [Route("api/v1/avatar")]
    public class AvatarController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AvatarController(AppDbContext db) => _db = db;

        [HttpGet("v2")]
        [Authorize]
        public async Task<IActionResult> GetAvatar()
        {
            var accountId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            var avatar = await _db.Avatars.FindAsync(accountId);
            return Ok(avatar?.Data ?? "{}");
        }

        [HttpPost("v2")]
        [Authorize]
        public async Task<IActionResult> UpdateAvatar([FromBody] object data)
        {
            var accountId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            var avatar = await _db.Avatars.FindAsync(accountId);
            if (avatar == null)
            {
                avatar = new Avatar { AccountId = accountId, Data = data.ToString() };
                _db.Avatars.Add(avatar);
            }
            else
            {
                avatar.Data = data.ToString();
            }
            await _db.SaveChangesAsync();
            return Ok();
        }
    }

    [ApiController]
    [Route("api/v1/rooms")]
    public class RoomsController : ControllerBase
    {
        [HttpGet("featured")]
        public IActionResult GetFeatured()
        {
            return Ok(new[] { 
                new { RoomId = "dorm", Name = "DormRoom", MaxPlayers = 1 },
                new { RoomId = "park", Name = "RecCenter", MaxPlayers = 20 }
            });
        }
    }

    [ApiController]
    [Route("api/v1/images")]
    public class ImagesController : ControllerBase
    {
        [HttpGet("v1")]
        public IActionResult GetImages() => Ok(new object[0]);
    }
}
