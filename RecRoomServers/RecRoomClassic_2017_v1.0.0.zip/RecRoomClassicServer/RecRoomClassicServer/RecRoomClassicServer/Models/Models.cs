using System.ComponentModel.DataAnnotations;

namespace RecRoomClassicServer.Models
{
    public class Account
    {
        [Key]
        public int AccountId { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public int RegistrationStatus { get; set; } = 1;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class Room
    {
        [Key]
        public string RoomId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int CreatorAccountId { get; set; }
        public int MaxPlayers { get; set; } = 20;
        public bool IsPublic { get; set; } = true;
    }

    public class Avatar
    {
        [Key]
        public int AccountId { get; set; }
        public string Data { get; set; } // JSON string of avatar items/colors
    }
}
