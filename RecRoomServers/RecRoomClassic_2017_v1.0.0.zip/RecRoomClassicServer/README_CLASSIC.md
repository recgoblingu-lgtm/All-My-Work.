# Rec Room 2017 Classic Server & Patcher

This package contains everything you need to run a private server for **Rec Room 2017** builds on your local machine.

## 📦 What's Included
1.  **`RecRoomClassicServer/`**: The C# backend project.
2.  **`patcher_2017.py`**: A tool to point your 2017 game build to `localhost:5000`.

## 🚀 Getting Started

### 1. Run the Server
- Make sure you have the **.NET 8 SDK** installed.
- Open a terminal in the `RecRoomClassicServer/RecRoomClassicServer` folder.
- Run the command:
  ```bash
  dotnet run --urls "http://localhost:5000"
  ```
- Your server is now running at `http://localhost:5000`.

### 2. Patch your 2017 Build
- Copy `patcher_2017.py` to your computer.
- Run it using Python: `python patcher_2017.py`.
- When asked, enter the path to your **Rec Room 2017** folder.
- The tool will automatically find and patch `Assembly-CSharp.dll` or `global-metadata.dat`.

### 3. Play!
- Launch the game.
- It will connect to your local server.
- **Auto-Registration** is enabled: just type any username and password to create an account and log in!

## 🛠️ Features
- **Auto-Registration:** No sign-up page needed.
- **Classic API:** Supports the older 2017 endpoints.
- **Localhost Only:** Defaulted to `localhost:5000` for easy testing.

## ⚠️ Notes
- This is a "Classic" server and may not support every single feature of the 2017 build (like every specific room or item), but it provides the core login and room joining logic.
- For multiplayer, you will still need to configure a **Photon App ID** in `appsettings.json` if you want to play with others.
